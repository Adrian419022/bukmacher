export enum LocalStorageKeys {
  accessToken = 'access-token',
  refreshToken = 'refresh-token',
  refreshTokenExp = 'refresh-token-exp',
  redirectAfterLogin = 'login-redirect'
}
