export interface UserAccountModel {
  money: number;
  bankAccount: string;
}
