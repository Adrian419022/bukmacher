export interface UserAddressModel {
  city: string;
  street: string;
  state: string;
  postalCode: string;
}
