export interface LoginRequestProps {
  email: string;
  password: string;
}
