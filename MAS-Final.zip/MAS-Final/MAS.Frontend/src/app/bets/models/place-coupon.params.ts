export interface PlaceCouponParams {
  idUser?: number;
  betSportOptionIds: number[];
  betEsportOptionIds: number[];
  amount: number;
}
