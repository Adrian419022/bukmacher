﻿namespace MAS.Backend.Shared.Enums;

public enum BetStatusEnum
{
    NotStarted = 1,
    InGame = 2,
    Win = 3,
    Lose = 4,
}