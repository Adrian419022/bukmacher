﻿namespace MAS.Backend.Responses.Users;

public record UserAddressResponse(string City, string State, string Street, string PostalCode);