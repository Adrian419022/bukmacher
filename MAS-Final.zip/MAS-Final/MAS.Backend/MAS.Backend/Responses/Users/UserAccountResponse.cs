﻿namespace MAS.Backend.Responses.Users;

public record UserAccountResponse(double Money, string BankAccount);
