﻿namespace MAS.Backend.Requests.Users;

public record AddMoneyRequest(double Amount, int IdUser);
