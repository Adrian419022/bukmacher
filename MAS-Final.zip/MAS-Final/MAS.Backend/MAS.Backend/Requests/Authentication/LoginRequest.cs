﻿namespace MAS.Backend.Requests.Authentication;

public record LoginRequest(string Email, string Password);